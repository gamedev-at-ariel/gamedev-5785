You should put these two files ".gitattributes" and ".gitignore" in the root of every Unity project that you upload to GitHub.
